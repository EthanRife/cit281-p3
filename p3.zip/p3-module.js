/* CIT 281
Name: Ethan Rife
Assignment: p3-modules
Description: Creating several module functions
*/

function validDenomination(coin) {return [1,5,10,25,50,100].indexOf(coin) !== -1;};

function valueFromCoinObject(obj) {
let {denom = 0, count = 0} = obj;
value = denom * count;
return value;
};

function valueFromArray(arr) {
    return arr.reduce((accumulator, currentValue) => {return accumulator + valueFromCoinObject(currentValue)});
};

function coinCount(...coinage) {
return valueFromArray(coinage);
};

module.exports = {coinCount};
